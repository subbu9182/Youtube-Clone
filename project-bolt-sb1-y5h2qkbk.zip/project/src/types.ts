export interface Video {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  videoUrl: string;
  views: number;
  likes: number;
  channel: {
    name: string;
    avatar: string;
    subscribers: number;
  };
  comments: Comment[];
}

export interface Comment {
  id: string;
  user: {
    name: string;
    avatar: string;
  };
  content: string;
  likes: number;
  timestamp: string;
}