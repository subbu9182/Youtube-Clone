import React from 'react';
import { Video } from '../types';
import { formatNumber } from '../utils/format';

interface VideoCardProps {
  video: Video;
  onSelect: (video: Video) => void;
}

export function VideoCard({ video, onSelect }: VideoCardProps) {
  return (
    <div 
      className="cursor-pointer group"
      onClick={() => onSelect(video)}
    >
      <div className="relative aspect-video rounded-xl overflow-hidden">
        <img 
          src={video.thumbnail} 
          alt={video.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
        />
      </div>
      <div className="mt-3 flex gap-3">
        <img 
          src={video.channel.avatar} 
          alt={video.channel.name}
          className="h-9 w-9 rounded-full"
        />
        <div>
          <h3 className="font-semibold line-clamp-2">{video.title}</h3>
          <p className="text-sm text-gray-600 mt-1">{video.channel.name}</p>
          <p className="text-sm text-gray-600">
            {formatNumber(video.views)} views
          </p>
        </div>
      </div>
    </div>
  );
}