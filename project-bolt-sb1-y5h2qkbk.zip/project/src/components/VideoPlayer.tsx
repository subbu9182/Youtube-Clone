import React from 'react';
import ReactPlayer from 'react-player';
import { ThumbsUp, Share2, MessageCircle } from 'lucide-react';
import { Video } from '../types';
import { formatNumber } from '../utils/format';

interface VideoPlayerProps {
  video: Video;
}

export function VideoPlayer({ video }: VideoPlayerProps) {
  return (
    <div className="max-w-4xl">
      <div className="aspect-video">
        <ReactPlayer
          url={video.videoUrl}
          width="100%"
          height="100%"
          controls
        />
      </div>
      
      <div className="mt-4">
        <h1 className="text-xl font-bold">{video.title}</h1>
        <div className="mt-2 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <img 
              src={video.channel.avatar} 
              alt={video.channel.name}
              className="h-10 w-10 rounded-full"
            />
            <div>
              <h3 className="font-semibold">{video.channel.name}</h3>
              <p className="text-sm text-gray-600">
                {formatNumber(video.channel.subscribers)} subscribers
              </p>
            </div>
            <button className="ml-4 bg-black text-white px-4 py-2 rounded-full">
              Subscribe
            </button>
          </div>
          
          <div className="flex items-center gap-4">
            <button className="flex items-center gap-2 hover:bg-gray-100 px-4 py-2 rounded-full">
              <ThumbsUp size={20} />
              {formatNumber(video.likes)}
            </button>
            <button className="flex items-center gap-2 hover:bg-gray-100 px-4 py-2 rounded-full">
              <Share2 size={20} />
              Share
            </button>
          </div>
        </div>
        
        <div className="mt-4 bg-gray-100 rounded-xl p-4">
          <p className="whitespace-pre-wrap">{video.description}</p>
        </div>
        
        <div className="mt-6">
          <div className="flex items-center gap-2 mb-4">
            <MessageCircle size={24} />
            <h3 className="text-xl font-semibold">
              {video.comments.length} Comments
            </h3>
          </div>
          
          {video.comments.map(comment => (
            <div key={comment.id} className="flex gap-4 mb-4">
              <img 
                src={comment.user.avatar} 
                alt={comment.user.name}
                className="h-10 w-10 rounded-full"
              />
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="font-semibold">{comment.user.name}</h4>
                  <span className="text-sm text-gray-600">{comment.timestamp}</span>
                </div>
                <p className="mt-1">{comment.content}</p>
                <div className="flex items-center gap-2 mt-2">
                  <button className="flex items-center gap-1 text-sm hover:bg-gray-100 px-2 py-1 rounded">
                    <ThumbsUp size={16} />
                    {formatNumber(comment.likes)}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}