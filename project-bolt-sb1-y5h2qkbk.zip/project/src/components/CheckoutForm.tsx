import React from 'react';
import { CreditCard, Smartphone, Truck } from 'lucide-react';

const paymentMethods = [
  { id: 'cod', name: 'Cash on Delivery', icon: Truck },
  { id: 'card', name: 'Credit Card', icon: CreditCard },
  { id: 'upi', name: 'UPI', icon: Smartphone },
];

interface CheckoutFormProps {
  onSubmit: (data: any) => void;
}

export function CheckoutForm({ onSubmit }: CheckoutFormProps) {
  const [selectedPayment, setSelectedPayment] = React.useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    const data = Object.fromEntries(formData);
    onSubmit({ ...data, paymentMethod: selectedPayment });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4">
        <h3 className="text-lg font-semibold">Billing Details</h3>
        <div className="grid grid-cols-2 gap-4">
          <input
            type="text"
            name="firstName"
            placeholder="First Name"
            required
            className="p-2 border rounded"
          />
          <input
            type="text"
            name="lastName"
            placeholder="Last Name"
            required
            className="p-2 border rounded"
          />
        </div>
        <input
          type="email"
          name="email"
          placeholder="Email"
          required
          className="w-full p-2 border rounded"
        />
        <input
          type="text"
          name="address"
          placeholder="Address"
          required
          className="w-full p-2 border rounded"
        />
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-semibold">Payment Method</h3>
        <div className="grid grid-cols-3 gap-4">
          {paymentMethods.map(({ id, name, icon: Icon }) => (
            <button
              key={id}
              type="button"
              onClick={() => setSelectedPayment(id)}
              className={`p-4 border rounded-lg flex flex-col items-center gap-2 ${
                selectedPayment === id ? 'border-blue-500 bg-blue-50' : ''
              }`}
            >
              <Icon size={24} />
              <span>{name}</span>
            </button>
          ))}
        </div>
      </div>

      <button
        type="submit"
        className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors"
      >
        Place Order
      </button>
    </form>
  );
}