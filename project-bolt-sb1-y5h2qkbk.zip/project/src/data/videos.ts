export const videos = [
  {
    id: "1",
    title: "Beautiful Mountain Sunrise",
    description: "Experience the breathtaking view of sunrise from the mountain top",
    thumbnail: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&q=80&w=1000",
    videoUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    views: 1500000,
    likes: 125000,
    channel: {
      name: "Nature Explorer",
      avatar: "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&q=80&w=200",
      subscribers: 500000
    },
    comments: [
      {
        id: "c1",
        user: {
          name: "John Doe",
          avatar: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?auto=format&fit=crop&q=80&w=200"
        },
        content: "This is absolutely stunning!",
        likes: 234,
        timestamp: "2 days ago"
      }
    ]
  },
  {
    id: "2",
    title: "Urban Photography Tips",
    description: "Learn professional tips for capturing stunning urban photographs",
    thumbnail: "https://images.unsplash.com/photo-1449824913935-59a10b8d2000?auto=format&fit=crop&q=80&w=1000",
    videoUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    views: 890000,
    likes: 75000,
    channel: {
      name: "Photo Pro",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200",
      subscribers: 750000
    },
    comments: [
      {
        id: "c2",
        user: {
          name: "Jane Smith",
          avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=200"
        },
        content: "These tips really helped improve my photography!",
        likes: 156,
        timestamp: "1 day ago"
      }
    ]
  }
];