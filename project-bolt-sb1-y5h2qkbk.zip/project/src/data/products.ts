export const products = [
  {
    id: 1,
    name: "Professional Cricket Bat",
    price: 199.99,
    image: "https://images.unsplash.com/photo-1531415074968-036ba1b575da?auto=format&fit=crop&q=80&w=1000",
    category: "Bats",
    description: "Premium willow cricket bat for professional players"
  },
  {
    id: 2,
    name: "Match Cricket Ball",
    price: 24.99,
    image: "https://images.unsplash.com/photo-1590592823321-f26ae0255e15?auto=format&fit=crop&q=80&w=1000",
    category: "Balls",
    description: "Regulation cricket ball for match play"
  },
  {
    id: 3,
    name: "Batting Gloves",
    price: 34.99,
    image: "https://images.unsplash.com/photo-1471295253337-3ceaaad65897?auto=format&fit=crop&q=80&w=1000",
    category: "Protection",
    description: "Professional batting gloves with extra padding"
  },
  {
    id: 4,
    name: "Cricket Helmet",
    price: 89.99,
    image: "https://images.unsplash.com/photo-1580744261846-e40fb85455a7?auto=format&fit=crop&q=80&w=1000",
    category: "Protection",
    description: "Safety-certified cricket helmet with adjustable fit"
  }
];