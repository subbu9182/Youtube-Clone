import React, { useState } from 'react';
import { Search, Menu } from 'lucide-react';
import { videos } from './data/videos';
import { VideoCard } from './components/VideoCard';
import { VideoPlayer } from './components/VideoPlayer';
import { Video } from './types';

function App() {
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredVideos = videos.filter(video =>
    video.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-white">
      <header className="fixed top-0 left-0 right-0 bg-white z-50 border-b">
        <div className="flex items-center justify-between px-4 h-14">
          <div className="flex items-center gap-4">
            <button className="hover:bg-gray-100 p-2 rounded-full">
              <Menu size={24} />
            </button>
            <h1 className="text-xl font-bold">YouTube Clone</h1>
          </div>
          
          <div className="flex-1 max-w-2xl mx-4">
            <div className="flex">
              <input
                type="text"
                placeholder="Search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full px-4 py-2 border rounded-l-full focus:outline-none focus:border-blue-500"
              />
              <button className="px-6 py-2 bg-gray-100 border border-l-0 rounded-r-full hover:bg-gray-200">
                <Search size={20} />
              </button>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <button className="bg-blue-500 text-white px-4 py-2 rounded-full hover:bg-blue-600">
              Sign In
            </button>
          </div>
        </div>
      </header>

      <main className="pt-14">
        {selectedVideo ? (
          <div className="flex max-w-[1800px] mx-auto p-6 gap-6">
            <div className="flex-1">
              <VideoPlayer video={selectedVideo} />
            </div>
            <div className="w-96">
              <h2 className="font-bold mb-4">Related Videos</h2>
              <div className="space-y-4">
                {filteredVideos
                  .filter(v => v.id !== selectedVideo.id)
                  .map(video => (
                    <VideoCard
                      key={video.id}
                      video={video}
                      onSelect={setSelectedVideo}
                    />
                  ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="max-w-[1800px] mx-auto p-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredVideos.map(video => (
                <VideoCard
                  key={video.id}
                  video={video}
                  onSelect={setSelectedVideo}
                />
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;